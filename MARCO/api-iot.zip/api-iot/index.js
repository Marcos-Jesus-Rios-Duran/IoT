import app from "./src/app.js"

app.listen(9222, () => {
    console.log(`Servidor listo en el puerto ${9222}`);
});
